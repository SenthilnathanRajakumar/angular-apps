export interface Booking {
    id: number;
    name: string;
    roomNumber: number;
    startDate: Date;
    endDate: Date;
}