export const environment = {
    apiUrl: ''
};
